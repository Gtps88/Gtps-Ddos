# Nulled-ddos-bot
# Do not use if you don't know what you're doing.
# STAR THE PROJECT IF YOU'RE USING IT.
This is a discord ddos bot that utilises ddos apis to send attacks via commands! The code is extremely messy as I never intended to release it when first writing it - and I would appreciate it if you didn't cry about that.

This bot has its own method renaming (naming a method on the bot "UDP" for example but it sending an attack using "TCP" on your api). It has maxtime and minimum time and channel ids for moderating it. It has its own .ping function to icmp ping targets.

Also, the api in this is old and inactive. I didn't replace all set ids and values to "REPLACE THIS", hence why I mentioned that if you are clueless, do not use this as it will not benefit you. It can definitely be improved and it is not something I updated consistently, it was my first javascript project too. 

**READ** Lastly, delete the comments in the config.json before using it, I have had over **40** people ask me about that so far.

# Educational Purposes Only
# I take no responsibility how you use this.
# Do NOT take credit for this.
# NO SUPPORT. (icba)
